function [X,Y] = getXnYNewModel(userData, getFeatures, signalTranformator)
% This function generates the feature matrix (X) and the labels (Y) of the
% INPUT:
%   userData - Structure with the user information (including the EMGs)
%   getFeature - Function handle that gets the feature vectors from rawEMG
%   signalTranformator - Function handle to preprocess the singal
%
% OUTPUT:
%   X - Feature matrix
%   Y - Vector of lables
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

%% Number of gestures
numGestures = length(userData.gestures.classes);

%% All cells
cellX = cell(numGestures,1);
cellY = cell(numGestures,1);

%% Loop
for gidx = 1:numGestures
    gesture = userData.gestures.classes{gidx};
    data = {userData.gestures.(gesture).data{:}};
    %% Get tmpX and tmpY
    tmpCellX = cellfun(@(dato)(conditionalFeatureExtraction(dato.emg, getFeatures, signalTranformator)), data, 'UniformOutput', false);
    tmpX = cell2mat(tmpCellX');
    tmpY = repmat(gesture2codeNewModel(gesture), size(tmpX,1), 1);
    %% Save in cell
    cellX{gidx,1} = tmpX;
    cellY{gidx,1} = tmpY;
end

%% Return the whole X and Y
X = cell2mat(cellX);
Y = cell2mat(cellY);
end

function features = conditionalFeatureExtraction(emg, getFeatures, signalTranformator)
    if size(emg,1) > 400
        [idxStart,idxEnd] = fallBackEMG(signalTranformator(emg), 100, 100);      
        emg = emg(idxStart:idxEnd,:);
    end
    features = getFeatures(emg);
end