function processedEMG = getSignalProcessor(rawEMG)
% Function handle that preprocess the rawEMG
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

%% Signal processor
% Filter
order = 4;
fs = 0.05;
type = 'low';
[Fb, Fa] = butter(order, fs, type); % filter values
SPOptions.Fa = Fa;
SPOptions.Fb = Fb;
% Signal Processor options
SPOptions.rectified = true;
SPOptions.filtered = true;
SPOptions.normalize = false;
SPOptions.normalizefactor = 1;

% Muscle detection activity options
SPOptions.detectMuscleActivity = false;
SPOptions.muscleActivity.fs = 200;
SPOptions.muscleActivity.minWindowLengthOfMuscleActivity = 100;
SPOptions.muscleActivity.threshForSumAlongFreqInSpec = 10;

signalTrainingProcessor = SignalProcessor(SPOptions);
processedEMG = signalTrainingProcessor.process(rawEMG);
end