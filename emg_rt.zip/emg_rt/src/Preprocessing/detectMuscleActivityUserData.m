function newUserData = detectMuscleActivityUserData(userData, detectActivityFunc, signalProcessor)
% Generates a newUserData with the muscle activity detection.
%
% INPUT:
%   userData - Structure with the userData
%   detectActivityFunc - Function handle to the muscle activity detection
%   signalProcessor - Function handle that preprocess the signal
%
% OUTPUT:
%   newUserData - User data after applyting the muscle activity detection
%   on every repetition.
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

%% Detect muscle activity
newUserData = userData;
for cellGesture = userData.gestures.classes
    gesture = cellGesture{:};
    emgData = {userData.gestures.(gesture).data{:}};
    newUserData.gestures.(gesture).data = ...
        cellfun(@(emgData) updateItem(gesture, emgData, signalProcessor, detectActivityFunc), emgData, 'UniformOutput', false);
end
end

%% Function to update the emg
function dataStruct = updateItem(gesture, dataStruct, signalProcessor, detectActivityFunc)
newEmg = dataStruct.emg;
emgPreprocessed = signalProcessor(newEmg);
[idxStart, idxEnd] = detectActivityFunc(emgPreprocessed);
if strcmp(gesture, 'relax')
    idxStart = 1;
    idxEnd = 200;
end
dataStruct.emg = newEmg(idxStart:idxEnd, :);
end