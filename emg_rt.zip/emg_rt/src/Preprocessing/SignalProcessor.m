% Class that handles the preprocessing of the rawEMG%
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

classdef SignalProcessor
    properties
        Options
    end
    
    methods
        function SP = SignalProcessor(Options)
            SP.Options = Options;
        end
        function signal = process(SP, signal)
            if SP.Options.rectified
                signal = abs(signal);
            end
            
            if SP.Options.filtered
                Fa = SP.Options.Fa;
                Fb = SP.Options.Fb;
                signal = filtfilt(Fb, Fa, signal);
            end

            if SP.Options.normalize
                signal = signal/SP.Options.normalizefactor;
            end
            if SP.Options.detectMuscleActivity
                [idxStart, idxEnd] = SP.detectMuscleActivity(signal);
                signal = signal(idxStart:idxEnd,:);
            end
        end

        function [idxStart, idxEnd] = detectMuscleActivity(SP, signal)
            [idxStart, idxEnd] = detectMuscleActivity(signal, SP.Options.muscleActivity);
        end
    end
end
