function individualPlotconfussions(ClassificationT, ClassificationO, users, numSamples)
% Plots the indivitual confussion matrices
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

N = numSamples*5;
for idx = 1:length(users)
    index = (idx - 1)*N + 1:idx*N;
    figure;
    plotconfusion(ClassificationT(:,index),ClassificationO(:,index));
    title(['User: ' users{idx}]);
end
end