function str = date2str(date)
% Transforms a date into a String
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

str = replace(datestr(date), ' ','-');
str = replace(str, ':','');
end

