function groups = groupBy(items)
% The groupBy function takes a list and returns a list of lists such that the
% concatenation of the result is equal to the argument. Moreover, each
% sublist in the result contains only equal elements. For example:
%
% groupBy "Mississippi" = ["M","i","ss","i","ss","i","pp","i"]
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

%% Data
groups = cell(1,length(unique(items)));
nIdx = 1;

%% Avoid empty arrays
if isempty(items)
    groups = [];
    return
end

%% Set first element
groups{nIdx} = items(1);

%% Loop
for idx = 2:length(items)
    if items(idx) == items(idx - 1)
        groups{nIdx} = [ groups{nIdx} items(idx) ];
    else
        nIdx = nIdx + 1;
        groups{nIdx} = [ items(idx) ];
    end
end
end