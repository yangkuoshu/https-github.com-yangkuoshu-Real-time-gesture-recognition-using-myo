function code = gesture2codeNewModel(gesture)
% Change the gesture label to a code.
% It is worth mentioning that 'relax' in this context refers to the
% 'no-gesture' clases.
% CODES:
%       NO_GESTURE     = 6
%       FIST           = 1
%       WAVE_IN        = 2
%       WAVE_OUT       = 3
%       FINGERS_SPREAD = 4
%       DOUBLE_TAP     = 5
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

switch gesture
    case 'fist'
        code = 1;
    case 'waveIn'
        code = 2;
    case 'waveOut'
        code = 3;
    case 'fingersSpread'
        code = 4;
    case 'doubleTap'
        code = 5;
    case 'relax'
        code = 6;
    otherwise
        code = 6;
end
end