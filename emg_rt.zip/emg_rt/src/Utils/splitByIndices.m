function newUserData = splitByIndices(userData,indices)
% Split the userData by the indices
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

newUserData = userData;
for idx = 1:length(userData.gestures.classes)
    gesture = userData.gestures.classes{idx};
    if strcmp(gesture,'relax') && max(indices) > 10
        newUserData.gestures.(gesture).data = userData.gestures.(gesture).data(:);
        continue
    end
    newUserData.gestures.(gesture).data = userData.gestures.(gesture).data(indices);
end