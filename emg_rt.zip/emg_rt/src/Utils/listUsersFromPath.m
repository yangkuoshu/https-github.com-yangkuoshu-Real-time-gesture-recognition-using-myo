function users = listUsersFromPath(path)
% List the directories and files in a path.
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

dirData = dir(path);
dirs = {dirData.name};
idx1 = find(ismember(dirs, '.'));
idx2 = find(ismember(dirs, '..'));
dirs([idx1,idx2]) = [];
users = dirs;
end