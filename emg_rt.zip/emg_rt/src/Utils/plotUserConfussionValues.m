function plotUserConfussionValues(ClassificationT, ClassificationO, users, numSamples)
% Plots a graph with the user confussion values in a line.
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

N = numSamples*5;
numUsers = length(users);
confusionValues = zeros(1,numUsers);
for idx = 1:numUsers
    index = (idx - 1)*N + 1:idx*N;
    confusionValues(idx) = confusion(ClassificationT(:,index),ClassificationO(:,index));
end
figure;
hold on
plot(1-confusionValues);
plot([1 numUsers], [mean(1-confusionValues) mean(1-confusionValues)]);
plot([1 numUsers], [0.85 0.85],'Color','red');
title('Accuracy Values');
ylim([0 1]);
xticks(1:numUsers);
xticklabels(users);
xtickangle(90);
hold off
end