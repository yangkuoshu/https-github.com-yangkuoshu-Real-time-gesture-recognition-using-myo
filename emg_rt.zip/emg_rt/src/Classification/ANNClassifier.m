% This class abstract the common operations that we perform with the 
% Artificial Neuronal Network:
%   - Train the ANN
%   - Predict a gesture
%   - Postprocessing the results
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%
classdef ANNClassifier < handle
    properties
        Options
        Weights
        Theta
        meanX
        stdX
        accuracy_rate
        cost_rate
        expectedOptions = {'thresholdPostprocesing', 'tearDownWith'...
            'numNeuronsLayers','transferFunctions'};
    end
    
    methods
        %% Constructor
        function CL = ANNClassifier(X,Y, Options)
            %% Check existence of paratemers
            allAreSetted = all(cellfun(@(attr)(isfield(Options, attr)), CL.expectedOptions));
            if allAreSetted
                CL.Options = Options;
            else
                msg = 'You need to provide Options with: ';
                for idx = 1:length(CL.expectedOptions)
                    msg = [ msg, CL.expectedOptions{idx},  ', ' ];
                end
                error(msg);
            end
            
            %% Set meanX and stdX if Options.requiresStandarization
            if Options.requiresStandarization
                CL.meanX = mean(X);
                CL.stdX = std(X);
                X = standarization(X);
            else
                CL.meanX = 0;
                CL.stdX = 1;
            end
            %% Train
            [CL.Weights, CL.accuracy_rate, CL.cost_rate, CL.Theta] = trainSoftmaxNN(X, Y, ...
                Options.numNeuronsLayers, Options.transferFunctions, Options.options);
        end
        
        %% Prediction
        function [probability, prediction] = predict(CL, featureMatrix)
            if CL.Options.requiresStandarization
                featureMatrix = (featureMatrix - CL.meanX) ./ CL.stdX;
            end
            
            [~, A] = forwardPropagation(featureMatrix, CL.Weights, CL.Options.transferFunctions, CL.Options.options);
            P = A{end};
            [~, predictions] = max(P, [], 2);
            [probability, prediction] = maxProbPredictions(predictions, CL.Options.gestureCodes);
            [probability, prediction] = CL.postprocessing(probability, prediction);
        end
        
        %% Postprocessing
        function [probability, prediction] = postprocessing(CL, probability, prediction)
            if probability < CL.Options.thresholdPostprocesing
                prediction = CL.Options.tearDownWith;
            end
        end
        
        %% Retrain
        function retrain(CL, X,Y)
            [CL.Weights, CL.accuracy_rate, CL.cost_rate, CL.Theta] = trainSoftmaxNN(X, Y, ...
                CL.Options.numNeuronsLayers, CL.Options.transferFunctions, CL.Options.options, CL.Theta);
        end
    end
end