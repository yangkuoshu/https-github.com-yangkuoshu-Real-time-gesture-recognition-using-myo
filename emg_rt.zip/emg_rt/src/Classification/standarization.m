function value = standarization(X)
% From Wikipedia:
% Feature standardization makes the values of each feature in the data have
% zero-mean (when subtracting the mean in the numerator) and unit-variance.
% This method is widely used for normalization in many machine learning
% algorithms (e.g., support vector machines, logistic regression, and neural networks)
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

value = (X - mean(X)) ./ std(X);
end