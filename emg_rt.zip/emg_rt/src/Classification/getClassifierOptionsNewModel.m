function opts = getClassifierOptionsNewModel(inputSize)
% Options for the Artificial Neuronal Network
% The inputSize stablishes the number of nodes for the input and hidden
% layers of the ANN.
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

%% Classifier options
opts.numNeuronsLayers = [ inputSize inputSize/2 6 ];
opts.transferFunctions{1} = 'none';
opts.transferFunctions{2} = 'tanh';
opts.transferFunctions{3} = 'softmax';
opts.gestureCodes = 1:6;

opts.options.reluThresh = 1e-3;
opts.options.lambda = 150;
opts.options.numIterations = 100;

opts.requiresStandarization = true;
opts.options.verbose = false;
opts.thresholdPostprocesing = 0.7;
opts.tearDownWith = gesture2codeNewModel('relax');
end