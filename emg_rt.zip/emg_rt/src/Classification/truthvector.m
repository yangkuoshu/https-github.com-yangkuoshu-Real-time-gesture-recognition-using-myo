function TV = truthvector( code )
% Transform a code into a Output Vector
%   CODES:
%       NO_GESTURE     = [1,0,0,0,0,0]
%       FIST           = [0,1,0,0,0,0]
%       WAVE_IN        = [0,0,1,0,0,0]
%       WAVE_OUT       = [0,0,0,1,0,0]
%       FINGERS_SPREAD = [0,0,0,0,1,0]
%       DOUBLE_TAP     = [0,0,0,0,0,1]
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

    switch code
        case 0
            TV = [1;0;0;0;0;0];
        case 1
            TV = [0;1;0;0;0;0];
        case 2
            TV = [0;0;1;0;0;0];
        case 3
            TV = [0;0;0;1;0;0];
        case 4
            TV = [0;0;0;0;1;0];
        case 5
            TV = [0;0;0;0;0;1];
        case 6
            TV = [1;0;0;0;0;0];
        otherwise
            TV = [1;0;0;0;0;0];
    end
end
