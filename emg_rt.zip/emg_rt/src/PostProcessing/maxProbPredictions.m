function [probability, prediction] = maxProbPredictions( predictions, targets )
% Gets the prediction within predictions with the max probability.
% Returns both: the probability and the element.
%
% INPUT:
%   predictions - The vector of predictions in a window
%   targets - All the posible target outputs
%
% OUTPUT:
%   probability - The probability of the gesture in the main window
%   prediction - The final prediction in the main window
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

cmp = @(x) (length(predictions(predictions == x)));
total = arrayfun(cmp, targets);
[value,index] = max(total);
probability = value/length(predictions);
prediction = targets(index);
end