function MAV = mav( signal )
% Mean Absolute Value
%  This is the Mean Absolute Value of a signal, is the estimate of
%  summation absolute value and measure contraction level of the EMG signals.
%
%   INPUT:
%       s(t) - signal in the time domain
%
%   OUTPUT:
%       MVA - Mean Absolute Value
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

MAV = sum(abs(signal)) / length(signal);
end