function HJORTH_PARAMETERS = hjorth(emgSignal)
% Hjorth Parameters are indicators of statistical properties used in signal
% processing in the time domain introduced by Bo Hjorth in 1970.
% The parameters are Activity, Mobility, and Complexity
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

% Activity
ACT = @(signals) sum((signals - mean(signals,1)).^2)/size(signals,1);
% Mobility
MOB = @(emg) sqrt(ACT(diff(emg))./ACT(emg));
% Complexity
COMPLX = @(emg) MOB(diff(emg))./MOB(emg);

activities = ACT(emgSignal);
mobilities = MOB(emgSignal);
complexities = COMPLX(emgSignal);

HJORTH_PARAMETERS = [ activities, mobilities, complexities ];
end