function slopes = ssc(signals, epsilon)
%% Slope Sign Changes (SSC)
% A feature that measures
% the  frequency  at  which  the  sign  of  the  signal  slope  changes.
% Given three consecutive samples: x_i, x_i_2, x_i_3. the value of SSC is
% incremented by one if
%
% (x_i - x_i_2)*(x_i_2 + x_i_3) >= epsilon
%
% where epsilon > 0 is employed as  a  threshold  to  reduce  the impact of
% noise on this feature.
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

[rows, cols] = size(signals);
slopes = zeros(1, cols);
for colIdx = 1:cols
    signal = signals(:,colIdx);
    for idx = 2:rows - 1
        x_i = signal(idx - 1);
        x_i_2 = signal(idx);
        x_i_3 = signal(idx + 1);
        if (x_i - x_i_2)*(x_i_2 + x_i_3) >= epsilon
            slopes(colIdx) = slopes(colIdx) + 1;
        end
    end
end
end