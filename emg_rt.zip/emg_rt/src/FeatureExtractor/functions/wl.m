function WL = wl( signals )
%   WL - Waveform Length
%       It is the cumulative  variation  that  can  indicate  the  degree
%       variations of EMG signals.
%
%   INPUT:
%       s(t) - signal in the time domain
%
%   OUTPUT:
%       WL - Waveform Length
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

    WL = sum(abs(diff(signals)));
end
