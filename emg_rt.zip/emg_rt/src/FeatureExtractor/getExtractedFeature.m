function trainFeaturesData = getExtractedFeature(rawEMG, signalTrainingProcessor, opts, omitReshape)
% This functions retuns the feature matrix given a rawEMG, the
% preprocessing function handler, the options (that includes the
% sub-window size and the bag of function), and an optional value to decide
% if use or not the values of the signals.
%
% INPUT:
%   rawEMG - The raw content of the signal
%   signalTrainingProcessor - Function handler for the preprocessing
%   opts - Structure that includes
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

%% Get the total of new features
if isempty(opts.functions)
    extraFeatures = [];
else
    numsFeatures = [opts.functions(:).numFeatures];
    totalNewFeatures = sum(numsFeatures);

    %% Apply functions to every image in the window
    totalFeatureSize = size(rawEMG,1) - opts.numContinuosSamples;
    extraFeatures = zeros(totalFeatureSize, totalNewFeatures);
    for idxFun = 1:length(opts.functions)
        %% Get func features and number of features
        func = opts.functions(idxFun).func;
        numFeatures = opts.functions(idxFun).numFeatures;
        featuresNewFunc = zeros(totalFeatureSize, numFeatures);
        %% Apply functions one by one
        for idx = 1:totalFeatureSize
            indicesImageEMG = idx:opts.numContinuosSamples+idx;
            imageEMG = rawEMG(indicesImageEMG,:);
            result = func(imageEMG);
            featuresNewFunc(idx,:) = result;
        end
        %% Collect the result from all function application
        if idxFun == 1
            initial = 0;
        else
            initial = initial + numsFeatures(idxFun - 1);
        end
        colIndices = initial + 1 : sum(numsFeatures(1:idxFun));
        extraFeatures(:,colIndices) = featuresNewFunc;
    end
end

%% Training preprocessing
if exist('omitReshape','var') && omitReshape
    emgReshaped = [];
else
    preprocessedEMG = signalTrainingProcessor(rawEMG);
    emgReshaped = reshapeEMG(preprocessedEMG, opts.numContinuosSamples);
end
trainFeaturesData = [ emgReshaped extraFeatures ];
end