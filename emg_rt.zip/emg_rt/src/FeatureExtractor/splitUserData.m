function [userDataTrain, userDataTest] = splitUserData(userData, samplesTrain, repetitionsInSample)
% Splits the userData into two subset: one for training and other for
% testing.
%
% INPUT:
%   userData - Structure with the user input data
%   samplesTrain - Indices of samples for training
%   repetitionsInSample - Number of samples for training
%
% OUTPUT:
%   userDataTrain - First part of the userData
%   userDataTest - Second part of the userData
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

%% Size of samples
if exist('repetitionsInSample','var')
    sampleSize = repetitionsInSample;
else
    sampleSize = userData.extraInfo.repetitions;
end

%% Check exact amount of samples
if samplesTrain >= sampleSize
    fprintf('[ERROR]: The samples of training must be less than %d\n',...
        userData.extraInfo.repetitions);
    return
end

%% Random permutation and split
randomIndices = randperm(sampleSize);
idxTrainingSample = randomIndices(1:samplesTrain);
idxTestingSample = randomIndices((samplesTrain + 1):sampleSize);

%% Prepare userDataTrain
userDataTrain = splitByIndices(userData,idxTrainingSample);

%% Prepare userDataTest
userDataTest = splitByIndices(userData,idxTestingSample);
end