function [emgReshaped] = reshapeEMG( emg, N )
% Reshape the emg into a vector of samples.
% INPUT:
%   emg - The raw emg
%   N - The number of continuous samples
%
% OUTPUT:
%   emgReshaped - The EMG transformed into a vector
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

[rows, channels] = size(emg);
sizeReshape = rows - N;
emgReshaped = zeros(sizeReshape, channels*N);
for ri = 1:sizeReshape
    tmpEmg = emg(ri:ri+N-1, :);
    tmpEmgReshaped = reshape(tmpEmg', 1, []);
    emgReshaped(ri,:) = tmpEmgReshaped;
end
end