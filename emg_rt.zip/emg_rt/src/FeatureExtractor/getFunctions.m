function functions = getFunctions()
% Returns an array of structures with the bag of functions.
% INPUT: none
% OUTPUT:
%   functions - An array of structures with the following properties:
%       func - Function handler that gets the emg as input
%       numFeatures - Number of results from the function application
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

% MAV
mavOpts.func = @(emg) mav(abs(emg));
mavOpts.numFeatures = 8;
% ZC
zcOpts.func = @zc;
zcOpts.numFeatures = 8;
% Wamp
wampOpts.func = @wamp;
wampOpts.numFeatures = 8;
% WL
wlOpts.func = @wl;
wlOpts.numFeatures = 8;
% Histograms
nbins = 9;
histOpts.func = @(emgs)amp_histogram(emgs, nbins);
histOpts.numFeatures = 8*nbins;
% Slope Scope Changes
epsilon = 1e-3;
sscOpts.func = @(emg)ssc(emg, epsilon);
sscOpts.numFeatures = 8;
% Root Mean Square
rmsOpts.func = @rms;
rmsOpts.numFeatures = 8;
% Hjorth Parameters
hjorthOpts.func = @hjorth;
hjorthOpts.numFeatures = 8*3;
% Mean freq
meanFreqOpts.func = @meanfreq;
meanFreqOpts.numFeatures = 8;

functions = [ mavOpts, wlOpts, sscOpts, rmsOpts, hjorthOpts ];
end