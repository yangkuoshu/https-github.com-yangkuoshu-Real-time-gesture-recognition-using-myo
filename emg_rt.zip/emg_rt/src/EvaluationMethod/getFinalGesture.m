function finalGesture = getFinalGesture(allRecognizedGestures)
% Given a vector of responses from processing a repetition this functions
% only one label that marks the repetition.
%
% INPUT:
%   allRecognizedGestures - Vector of lables
%
% OUTPUT:
%   finalGesture - Final recognized gesture
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

uniqueGestures = unique(allRecognizedGestures);
withoutNoGesture = uniqueGestures(uniqueGestures ~= gesture2codeNewModel('relax'));
if length(withoutNoGesture) >= 1
    finalGesture = withoutNoGesture(1);
else
    finalGesture = gesture2codeNewModel('relax');
end
end