function [ClassificationTarget, ClassificationOutput, RecognizedGesturesCells] =...
    getTargetAndOutputNewModel(userDataTest, preprocess, classifier, options)
% Get the classification Target, classification  Output and the RecognizedGesturesCells
% in a testing set.
% INPUT:
%   userDataTest - User Data Test for testing
%   preprocess - Function to preprocess the input signals
%   classifier - Classifier with a @predict method
%   options - Structure with options for testing
%
% OUTPUT:
%   ClassificationTarget - Matrix with the target truthvectors
%   ClassificationTarget - Matrix with the output truthvectors
%   RecognizedGesturesCells - All the vectors of recognized gestures
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

%% Remove relax
userDataTest.gestures = rmfield(userDataTest.gestures, 'relax');
testingGestures = userDataTest.gestures.classes;
testingGestures(strcmp(testingGestures,'relax')) = [];

%% Target and Output
numGestures = length(testingGestures);
ClassificationTargetCell = cell(1,numGestures);
ClassificationOutputCell = cell(1,numGestures);
RecognizedGesturesCells = cell(1,numGestures);

%% Gestures
for gidx = 1:numGestures
    gesture = testingGestures{gidx};
    gestureData = userDataTest.gestures.(gesture);
    [ClassificationTargetCell{1,gidx}, ClassificationOutputCell{1,gidx}, RecognizedGesturesCells{1,gidx}] = ...
        targetAndOutputByGesture(gestureData, preprocess, classifier, options);
end

%% To matrices
ClassificationTarget = cell2mat(ClassificationTargetCell);
ClassificationOutput = cell2mat(ClassificationOutputCell);
end

function [ClassT,ClassO,RecognizedGesturesCells] = targetAndOutputByGesture(gestureData, preprocess, classifier, options)
%% Target and Output
numSamples = length(gestureData.data);
ClassCellO = cell(1,numSamples);
RecognizedGesturesCells = cell(1,numSamples);

%% Gesture 2 code, temportal T and O
codeTargetGesture = gesture2codeNewModel(gestureData.gestureName);
ClassT = repmat(truthvector(codeTargetGesture),1,numSamples);

%% Loop
for idx = 1:numSamples
    emg = gestureData.data{idx}.emg;
    [ClassCellO{1,idx}, RecognizedGesturesCells{1,idx}] =...
        getOutputByEMG(emg, preprocess, classifier, codeTargetGesture, options);
end

%% To matrices
ClassO = cell2mat(ClassCellO);
end

%% Get output
function [tmpClassO, recognizedGestures] = getOutputByEMG(emg, preprocessor, classifier, codeTargetGesture, options)
%% Get recognized gestures
recognizedGestures = getRecognizedGestures(emg, classifier, preprocessor, options);

%% Perform evaluation (classification and recognition)
resultClass = getFinalGesture(recognizedGestures);

%% Get output for classification
tmpClassO = truthvector(resultClass);
end
