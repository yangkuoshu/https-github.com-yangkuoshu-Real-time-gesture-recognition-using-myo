function [allGesturesRecognized, meanTimes] = getRecognizedGestures(rawEmg, classifier, preprocessor, options)
% Get the array of recognized gestures and the meanTimes for preprocessing
% all the windows present in the repetition.
% INPUT:
%   rawEMG - The matrix that represent the original signal
%   classifier - A classifier class that has present the @predict method
%   preprocessor - How to preprocess the rawEMG to predict the gesture
%   options - An structure with:
%       - Size of the Window
%       - Stride between Windows
% OUTPUT:
%   allGesturesRecognized - Vector with the recognized labels
%   meanTimes - Mean time after predicting the label that belongs a window
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

%% Padding start emg with zeros
padding = rand(options.windowSize,size(rawEmg,2))/100;
emg = [ padding; rawEmg ];

%% Start iteration
iter = 0;
while iter*options.jump + options.windowSize <= length(emg)
    %% Get EMG Window
    index = iter*options.jump + 1: iter*options.jump + options.windowSize;
    emg_window = emg(index,:);

    %% Update iteration
    iter = iter + 1;

    %% Remove low EMGs
    tic
    if sum(mav(emg_window)) < options.thresholdAvoidClassification
        gestureRecognized = gesture2codeNewModel('relax');
    else
        %% Process EMG
        featureMatrix = preprocessor(emg_window);
        %% Predict result
        [~, gestureRecognized] = classifier.predict(featureMatrix);
    end
    endtime = toc;
    %% Collect results
    allGesturesRecognized(iter) = gestureRecognized;
    meanTimes(iter) = endtime;
end