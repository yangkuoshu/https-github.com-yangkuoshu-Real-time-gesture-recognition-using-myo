function [weights, cost, trainingAccuracy] = trainSoftmaxNNSGD(users, metaParameters, stdOpts)
%% Set parameters for better understanding
% Model parameters
numEpochs = metaParameters.numEpochs;
numNeuronsLayers = metaParameters.numNeuronsLayers;
numEpochsToIncreaseMomentum = metaParameters.numEpochsToIncreaseMomentum;
transferFunctions = metaParameters.transferFunctions;
classifierOpts = metaParameters.classifierOpts;
% Momentum, alpha and velocity
momentum = metaParameters.initialMomemtum;
alpha = metaParameters.learningRate;
learningRate = metaParameters.learningRate;
velocity = metaParameters.initialVelocity;
% Users
menUsers = users.men;
numMen = length(menUsers);
womenUsers = users.women;
numWomen = length(womenUsers);
numUsers = numMen + numWomen;
transformedDataPath = metaParameters.transformedDataPath;
% Recovery
recoveryPath = metaParameters.recoveryPath;
startFromRecovery = metaParameters.startFromRecovery;

%% Initializing the Neural Network Parameters Randomly
cost = zeros(1,numEpochs);
mean = 0;
sigma = 0.02;
initialTheta = [];
for i = 2:length(numNeuronsLayers)
    W = normrnd(mean, sigma, numNeuronsLayers(i), numNeuronsLayers(i - 1) + 1);
    initialTheta = [initialTheta; W(:)];
end
theta = initialTheta;

%% Load data for recovery
if startFromRecovery
    loadStruct = load([ recoveryPath '/recoveryOptions.mat']);
    recoveryOptions = loadStruct.recoveryOptions;
    initialEpoch = recoveryOptions.initialEpoch;
    velocity = recoveryOptions.velocity;
    theta = recoveryOptions.theta;
    alpha = recoveryOptions.alpha;
    cost = recoveryOptions.cost;
else
    initialEpoch = 1;
end

%% Load users
users = listUsersFromPath(transformedDataPath);

%% Iterate epochs
for epoch = initialEpoch:numEpochs
    %% Logging
    fprintf('\nEpoch: %d/%d', epoch,numEpochs);
    %% Load user data transformed
    idx = mod(epoch, numUsers - 1) + 1;
    user = users{idx};
    saveFilePath = [ transformedDataPath '\' user '\training\trainData.mat'];
    loadStruct = load(saveFilePath);
    if metaParameters.requiresStandarization
        dataX = (loadStruct.dataX - stdOpts.meanX) ./ stdOpts.stdX;
    else
        dataX = loadStruct.dataX;
    end
    dataY = loadStruct.dataY;

    %% Compute cost and gradient
    [cost(epoch), gradient] = ...
        softmaxNNCostFunction(dataX, dataY,...
        numNeuronsLayers,...
        theta,...
        transferFunctions,...
        classifierOpts);
    
    %% Increase momentum after momIncrease iterations
    if epoch == numEpochsToIncreaseMomentum
        momentum = metaParameters.momentum;
    end

    velocity = momentum*velocity + alpha*gradient;
    theta = theta - velocity;
    % Annealing the learning rate
    alpha = learningRate*exp(-5*epoch/numEpochs);

    %% Reshaping the weight matrices
    numLayers = length(numNeuronsLayers);
    endPoint = 0;
    for i = 2:numLayers
        numRows = numNeuronsLayers(i);
        numCols = numNeuronsLayers(i - 1) + 1;
        numWeights = numRows*numCols;
        startPoint = endPoint + 1;
        endPoint = endPoint + numWeights;
        weights{i - 1} = reshape(theta(startPoint:endPoint), numRows, numCols);
    end

    %% Save files to continue later
    recoveryOptions.initialEpoch = epoch;
    recoveryOptions.velocity = velocity;
    recoveryOptions.theta = theta;
    recoveryOptions.alpha = alpha;
    recoveryOptions.cost = cost;
    if ~exist(recoveryPath, 'dir')
        mkdir(recoveryPath);
    end
    save([ recoveryPath '/recoveryOptions.mat'],'recoveryOptions')
end

%% Computing the training error
[~, A] = forwardPropagation(dataX, weights, transferFunctions, classifierOpts);
P = A{end};
[~, predictedLabels] = max(P, [], 2);
trainingAccuracy = 100*sum(predictedLabels == dataY)/length(dataY);
fprintf('\nTraining Accuracy of the NEURAL NETWORK: %1.2f %%\n\n', trainingAccuracy);
end