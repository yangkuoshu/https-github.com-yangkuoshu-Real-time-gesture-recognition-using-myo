function [idxStart, idxEnd] = detectMuscleActivity(emg, options)
fs = options.fs;
minWindowLengthOfMuscleActivity = options.minWindowLengthOfMuscleActivity;
numFreqOfSpec = 50;
hammingWdwLength = 25;
numSamplesOverlapBetweenWdws = 10;
threshForSumAlongFreqInSpec = options.threshForSumAlongFreqInSpec;
sumEMG = sum(emg, 2);
[spec, dummy, time] = spectrogram(sumEMG, hammingWdwLength, ...
    numSamplesOverlapBetweenWdws, numFreqOfSpec, fs, 'yaxis');
spec = abs(spec);
greaterThanThresh = [0, sum(spec, 1) >= threshForSumAlongFreqInSpec, 0];
diffGreaterThanThresh = abs(diff(greaterThanThresh));
if diffGreaterThanThresh(end) == 1
    diffGreaterThanThresh(end - 1) = 1;
end
diffGreaterThanThresh = diffGreaterThanThresh(1:(end - 1));
idxNonZero = find(diffGreaterThanThresh == 1);
idxOfSamples = floor(time*fs);
numIdxNonZero = length(idxNonZero);
switch numIdxNonZero
    case 0
        idxStart = 1;
        idxEnd = length(sumEMG);
    case 1
        idxStart = idxOfSamples(idxNonZero);
        idxEnd = length(sumEMG);
    otherwise
        idxStart = idxOfSamples(idxNonZero(1));
        idxEnd = idxOfSamples(idxNonZero(end) - 1);
end

numExtraSamples = 25;
idxStart = max(1, idxStart - numExtraSamples);
idxEnd = min(length(sumEMG), idxEnd + numExtraSamples);
if (idxEnd - idxStart) < minWindowLengthOfMuscleActivity
    idxStart = 1;
    idxEnd = length(sumEMG);
end
return