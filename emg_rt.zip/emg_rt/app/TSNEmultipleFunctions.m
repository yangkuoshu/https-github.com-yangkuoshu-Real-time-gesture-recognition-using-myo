% Plot the TSNE given a feature matrix.
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

%% Clear
clc;
clear;

%% Sub-window size
opts.numContinuosSamples = 75;

%% Set title test
titleTest = ['Sub-Window: '  num2str(opts.numContinuosSamples) ' samples'];

%% Functions
opts.functions = getFunctions();

%% Define signal transformator
%% Signal processor
signalTransformator = @getSignalProcessor;
featureExtractor = @(rawEMG) getExtractedFeature(rawEMG, signalTransformator, opts);

%% Detect muscle activity function
muscleActivity.fs = 200;
muscleActivity.minWindowLengthOfMuscleActivity = 50;
muscleActivity.threshForSumAlongFreqInSpec = 18;
muscleActivityFunc = @(emg) detectMuscleActivity(emg, muscleActivity);

%% Run example
sampleIndices = 1:5;
user = 'andresGuerra';
gender = 'men';
% gender = 'women';
loadStruct = load([ 'data\testing\' gender '\' user '\training\userData.mat']);
userData = loadStruct.userData;

%% Split data
userDataTrain = splitByIndices(userData, sampleIndices);

%% Get only muscle activity
userDataTrain = detectMuscleActivityUserData(userDataTrain, muscleActivityFunc, signalTransformator);

%% Get X and Y for the classifier
[X, Y] = getXnYNewModel(userDataTrain, featureExtractor, signalTransformator);

%% Run TSNe
[Ytsne, loss] = tsne(X);

%% Plot result
figure;
gscatter(Ytsne(:,1), Ytsne(:,2), Y);
legend({'Double Tap', 'Fingers Spread', 'Fist', 'No Gesture', 'Wave Out', 'Wave In'});
title(titleTest);