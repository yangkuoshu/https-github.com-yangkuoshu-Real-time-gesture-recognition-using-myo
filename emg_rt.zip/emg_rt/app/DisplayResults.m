%% Load results
resultsDate = datetime(2018,04,22,9,37,48);
path = ['data/results/newModel/adaptedToUser/' date2str(resultsDate) '/sample_75/' ];
load([ path 'AllRecognizedGestureCells' ]);
load([ path 'classifierOpts' ]);
load([ path 'classO' ]);
load([ path 'classT' ]);
load([ path 'evaluationOpts' ]);
load([ path 'muscleActivityOpts' ]);
load([ path 'NSAMPLES' ]);
load([ path 'users' ]);

%% Plot confusion
figure;
plotconfusion(ClassificationT,ClassificationO);
labels = {'No-Gesture','Fist', 'Wave In', 'Wave Out', 'Fingers Spread', 'Double Tap'};
xticklabels(labels);
yticklabels(labels);
xtickangle(45);

%% Full confussion values
plotUserConfussionValues(ClassificationT, ClassificationO, users, NSAMPLES);

%% Individual confussion matrix
individualPlotconfussions(ClassificationT, ClassificationO, users, NSAMPLES);