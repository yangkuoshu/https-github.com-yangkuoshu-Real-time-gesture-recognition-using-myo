%% Clear workspace
clc;
clear;

%% Get a random user from the training set
genders = {'men', 'women'};
NGENDERS = length(genders);
gender = genders(mod(floor(rand()*10),NGENDERS) + 1);
users = listUsersFromPath(['data/testing/' gender{:}]);
NUSERS = length(users);
testUser = users(mod(floor(rand()*10),2) + 1);
testUserPath = ['data/testing/' gender{:} '/' testUser{:} '/' ];

%% Detect muscle activity function
muscleActivity.fs = 200;
muscleActivity.minWindowLengthOfMuscleActivity = 50;
muscleActivity.threshForSumAlongFreqInSpec = 18;
muscleActivityFunc = @(emg) detectMuscleActivity(emg, muscleActivity);

%% Signal processor and feature extractor
% Window size
ommitReshape = true;
opts.numContinuosSamples = 75;
% Functions
opts.functions = getFunctions();

signalTransformator = @getSignalProcessor;
featureExtractor = @(rawEMG) getExtractedFeature(rawEMG, signalTransformator, opts, ommitReshape);

%% Get only 5 repetitions per user
loadStructTrain = load([ testUserPath 'training/userData.mat' ]);
tmpUserTrainData = loadStructTrain.userData;
userDataTrain = detectMuscleActivityUserData(tmpUserTrainData, muscleActivityFunc, signalTransformator);
loadStructTest = load([ testUserPath 'testing/userData.mat' ]);
tmpUserDataTest = loadStructTest.userData;
userDataTest = splitUserData(tmpUserDataTest, 5, 30);

%% Train classifier
% Get input size
fakeEMG = rand(opts.numContinuosSamples,8);
inputSize = size(featureExtractor(fakeEMG),2);

% Classifier options
opts.numNeuronsLayers = [ inputSize inputSize/2 6 ];
opts.transferFunctions{1} = 'none';
opts.transferFunctions{2} = 'tanh';
opts.transferFunctions{3} = 'softmax';
opts.gestureCodes = 1:6;

opts.options.reluThresh = 1e-3;
opts.options.lambda = 1e2;
% opts.options.lambda = 1e1;
opts.options.numIterations = 75;

opts.requiresStandarization = true;
opts.options.verbose = false;
opts.thresholdPostprocesing = 0.7;
opts.tearDownWith = gesture2codeNewModel('relax');

% Get X and Y
[X, Y] = getXnYNewModel(userDataTrain, featureExtractor, signalTransformator);
% Train classifier
tic
classifier = ANNClassifier(X, Y, opts);
trainTime = toc;

%% Get times
options.windowSize = 200;
options.jump = 20;
options.thresholdAvoidClassification = 50/128;
allEmgs = {};
for gesture = userDataTest.gestures.classes
    if strcmp(gesture, 'relax')
        continue
    end
    data = [userDataTest.gestures.(gesture{:}).data];
    tmpData = [data{:}];
    emgs = {tmpData.emg};
    allEmgs = { allEmgs{:} emgs{:} };
end

%% Get mean times
allTimes = []; 
for emg = allEmgs
    rawEmg = emg{:};
    [~, meanTimes] = getRecognizedGestures(rawEmg, classifier, featureExtractor, options);
    allTimes = [ allTimes meanTimes ];
end

%% Print results
fprintf('Training Time: %.2f [s]\n', trainTime);
fprintf('Mean time: %.2f [ms]\n', mean(allTimes)*1000);