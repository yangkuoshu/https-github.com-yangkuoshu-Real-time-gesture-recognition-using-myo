% Compare the saved results from t-SNE
%
% Cristhian Motoche
% Escuela Politecnica Nacional
% cristhian.motoche@epn.edu.ec
% (C) Copyright Cristhian Motoche
%

subWindowSizes = [ 10 50 75 150 ];

figure;

for idx = 1:length(subWindowSizes)
    sw = subWindowSizes(idx);
    subplot(2,2,idx);
    load(['data/tsne/samples_' num2str(sw) '/tsne-results.mat']);
    gscatter(Ytsne(:,1), Ytsne(:,2), Y);
    legend({'Double Tap', 'Fingers Spread', 'Fist', 'No Gesture', 'Wave Out', 'Wave In'});
    titleTest = ['Sub-Window length N = ' num2str(sw)];
    title(titleTest);
end