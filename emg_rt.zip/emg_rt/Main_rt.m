%%% Real time 
% Please cite the following paper if you use the code or the proposed technique:
% Zhen Zhang, Kuo Yang, Jinwu Qian and Lunwei Zhang. Real-Time Surface EMG Pattern Recognition for Hand Gestures Based on an Artificial Neural Network. 
%Sensors. 19, 3170. doi:10.3390/s19143170.
% Questions? => zhangzhen_ta@shu.edu.cn

%% Set random values
rng('default');
%% Clear workspace and add current files to workspace
clc;
clear;
addpath(genpath(pwd));
tic
%% Load User Data
versions = {'training','testing'};
versionTrain = versions{1};
versionTest = versions{2};
path = [ 'data/' versions{2} '/' ];
users = listUsersFromPath(path);
% user = {users{6}};

%% Choose random samples for training
samplesTrain = 5;
sampleIndices = randperm(samplesTrain);

%% Function to detect muscle activity
muscleActivity.fs = 200;
muscleActivity.minWindowLengthOfMuscleActivity = 50;
muscleActivity.threshForSumAlongFreqInSpec = 18;
muscleActivityFunc = @(emg) detectMuscleActivity(emg, muscleActivity);

windowSize=40;
%% Evaluation options
evaluationOps.windowSize = windowSize+1; % 200 samples -> 1 second
evaluationOps.jump = 1; 
evaluationOps.thresholdAvoidClassification = 50/128; % Around 40% of Amplitute

%% Evaluation results
loadStruct = load([users{1} '/' versionTest '/userData.mat' ]);
userDataTest = loadStruct.userData;
NSAMPLES = length(userDataTest.gestures.fist.data); % Data inside usersDataTest
NGESTURES = 5; % Number of gestures without relax
NUMEXTRACLASES = 1; % No-Gesture
NUSERS = length(users);
accuracies = zeros(1, NUSERS);
iterActivities = cell(1,NUSERS);

ClassificationT = zeros(NGESTURES + NUMEXTRACLASES, NUSERS*NSAMPLES*NGESTURES); %6,1500=5*30*10
ClassificationO = zeros(NGESTURES + NUMEXTRACLASES, NUSERS*NSAMPLES*NGESTURES);
AllRecognizedGestureCells = cell(1,NUSERS);

%% Sub-window Size
ommitReshape = false;
opts.numContinuosSamples = windowSize;

%% Bag of Functions
opts.functions = getFunctions();

%% Signal processor
signalTransformator = @getSignalProcessor;
featureExtractor = @(rawEMG) getExtractedFeature(rawEMG, signalTransformator, opts, ommitReshape);

%% Get classifier options
fakeEMG = rand(opts.numContinuosSamples,8);
inputSize = size(featureExtractor(fakeEMG),2);
optsClassifier = getClassifierOptionsNewModel(inputSize);

uidx = 1;
for user = users
%% Train classifier based on the amount of indices
% Loading training data
loadStruct = load([user{:} '\' versionTrain '\userData.mat']);
userData = loadStruct.userData;
% Split data
userDataTrain = splitByIndices(userData, sampleIndices);
% Get only muscle activity
userDataTrain = detectMuscleActivityUserData(userDataTrain, muscleActivityFunc, signalTransformator);
% Get X and Y for the classifier
[X, Y] = getXnYNewModel(userDataTrain, featureExtractor, signalTransformator);
%% Train classifier
classifier = ANNClassifier(X, Y, optsClassifier);
%% Load user data test
loadStruct = load([user{:} '/' versionTest '/userData.mat' ]);
userDataTest = loadStruct.userData;
%% Test the classifier
%% Remove relax
userDataTest.gestures = rmfield(userDataTest.gestures, 'relax');
testingGestures = userDataTest.gestures.classes;
testingGestures(strcmp(testingGestures,'relax')) = [];

%% Target and Output
numGestures = length(testingGestures);
ClassificationTargetCell = cell(1,numGestures);
ClassificationOutputCell = cell(1,numGestures);
RecognizedGesturesCells = cell(1,numGestures);

iterActivity = cell(1,numGestures);
%% Gestures
for gidx = 1:numGestures
    gesture = testingGestures{gidx};
    gestureData = userDataTest.gestures.(gesture);
    [ClassificationTargetCell{1,gidx}, ClassificationOutputCell{1,gidx}, RecognizedGesturesCells{1,gidx},iterActivity{1,gidx}] = ...
        targetAndOutputByGesture(gestureData, featureExtractor, classifier, evaluationOps);
end
%% To matrices
userClassifT = cell2mat(ClassificationTargetCell);
userClassifO = cell2mat(ClassificationOutputCell);

recognizedGestures=RecognizedGesturesCells;
%% Print confussion value
fprintf('\nConfussion value: %.2f\n', confusion(userClassifT, userClassifO));
fprintf('\nAccuracy value: %.2f\n', 1- confusion(userClassifT, userClassifO));
accuracies(uidx)=1- confusion(userClassifT, userClassifO);
iterActivities(uidx)={iterActivity};
%% Get index
    %% Get index
    index = (uidx - 1)*NSAMPLES*NGESTURES + 1 : uidx*NSAMPLES*NGESTURES;
    %% Fill targets and outputs
    ClassificationT(:, index) = userClassifT;
    ClassificationO(:, index) = userClassifO;
 AllRecognizedGestureCells(uidx) = {recognizedGestures};
    uidx = uidx + 1;
end
%% Fill targets and outputs
finalT = toc;
finalT 

%% Plot confusion
figure;
plotconfusion(ClassificationT,ClassificationO);
labels = {'No-Gesture','Fist', 'Wave In', 'Wave Out', 'Fingers Spread', 'Double Tap'};
xticklabels(labels);
yticklabels(labels);
xtickangle(15);

%% Full confussion values
plotUserConfussionValues(ClassificationT, ClassificationO, users, NSAMPLES);

%% Individual confussion matrix
individualPlotconfussions(ClassificationT, ClassificationO, users, NSAMPLES);

function [ClassT,ClassO,RecognizedGesturesCells,iterActivity] = targetAndOutputByGesture(gestureData, preprocess, classifier, options)
%% Target and Output
numSamples = length(gestureData.data);
ClassCellO = cell(1,numSamples);
RecognizedGesturesCells = cell(1,numSamples);
iterActivity=cell(1,numSamples);
%% Gesture 2 code, temportal T and O
codeTargetGesture = gesture2codeNewModel(gestureData.gestureName);
ClassT = repmat(truthvector(codeTargetGesture),1,numSamples);

%% Loop
for idx = 1:numSamples
    emg = gestureData.data{idx}.emg;
    [ClassCellO{1,idx}, RecognizedGesturesCells{1,idx},iterActivity{1,idx}] =...
        getOutputByEMG(emg, preprocess, classifier, codeTargetGesture, options);
end

%% To matrices
ClassO = cell2mat(ClassCellO);
end

%% Get output
function [tmpClassO, recognizedGestures, iterActivity] = getOutputByEMG(emg, preprocessor, classifier, codeTargetGesture, options)
%% Get recognized gestures
%recognizedGestures = getRecognizedGestures(emg, classifier, preprocessor, options);
%% Padding start emg with zeros
predicted=zeros(5,1);
maxFit = 40;
%% Start iteration
iter = 0;
iterActivity = 0;
while iter*options.jump + options.windowSize <= length(emg)
    %% Get EMG Window
    index = iter*options.jump + 1: iter*options.jump + options.windowSize;
    emg_window = emg(index,:);

    %% Update iteration
    iter = iter + 1;

    %% Remove low EMGs
    tic
    if sum(mav(emg_window)) < options.thresholdAvoidClassification
        gestureRecognized = gesture2codeNewModel('relax');
        posMax = 6;
    else
        iterActivity=iterActivity+1;
        %% Process EMG
        featureMatrix = preprocessor(emg_window);
        %% Predict result
        [~, gestureRecognized] = classifier.predict(featureMatrix);
        if(gestureRecognized < 6)
            predicted(gestureRecognized)=predicted(gestureRecognized)+1;
        end
        [maxPredicted, posMax]=max(predicted);
        if(maxPredicted>maxFit)
            break;
        end
        posMax = 6;
    end
    %% Collect results
    recognizedGestures(iter) = gestureRecognized;
end
%% Perform evaluation (classification and recognition)
resultClass = posMax;
%% Get output for classification
tmpClassO = truthvector(resultClass);
end

